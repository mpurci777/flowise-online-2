# Flowise Railway Deploy (Persistencia PostgreSQL)

Este proyecto está listo para desplegar Flowise en Railway usando Docker y una base de datos PostgreSQL con persistencia.

## Pasos

1. Subí este repositorio a tu cuenta de GitHub.
2. En Railway, seleccioná "Deploy from GitHub Repo".
3. Agregá tu base de datos PostgreSQL al proyecto desde "➕ New" → "Link existing service".
4. Listo: Flowise con persistencia funcionando.

Login por defecto:
- Usuario: admin
- Contraseña: admin123